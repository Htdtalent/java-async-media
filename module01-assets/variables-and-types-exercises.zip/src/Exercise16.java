public class Exercise16 {

    public static void main(String[] args) {
        // 1. Change the value of favoriteFood to your favorite food.
        // 2. Run the code.
        String favoriteFood = "mold";
        System.out.println("Favorite Food: " + favoriteFood);
    }
}
