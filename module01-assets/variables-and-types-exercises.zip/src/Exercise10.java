public class Exercise10 {

    public static void main(String[] args) {

        float kmPerHour = 125.25f;
        float hours = 1.75f;

        // 1. Given the variables above, calculate the kilometers traveled.
        // 2. Store the value in a new variable.
        // 3. Print the result.
        // Expected value: 219.1875.
    }
}
