# Exercise06

1. Add a class to this project named `Balloon`.
2. Add two private fields:
    - `String color`: balloon's color
    - `double psi`: balloon's pressure in lbs/sq inch
3. Add a constructor that accepts a `String` color and sets the field. Do not set psi.
4. Add getters for both color and psi. (psi will always have its default value 0.0)