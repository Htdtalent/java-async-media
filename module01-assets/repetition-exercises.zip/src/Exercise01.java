public class Exercise01 {

    public static void main(String[] args) {
        // The code below prints the numbers 0, 1, 2, 3, 4 each on its own line.
        // 1. Modify the code to print the numbers 1 - 10 each on its own line.
        // You may not change the loop type. It must remain a `while`.

        // Expected Output
        // 1
        // 2
        // 3
        // 4
        // 5
        // 6
        // 7
        // 8
        // 9
        // 10

        int index = 0;
        while (index < 5) {
            System.out.println(index);
            index++;
        }
    }
}
