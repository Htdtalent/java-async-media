public class Exercise08 {

    public static void main(String[] args) {
        // 1. The code below doesn't work. Uncomment it.
        // Fix it without changing the variable's data type.
        /*
        float f = 123.456;

        System.out.println(f);
         */
    }
}
