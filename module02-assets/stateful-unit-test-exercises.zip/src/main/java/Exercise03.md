# Exercise03

1. Create a new class `learn.chess.Knight`.
2. Model its location with integer `row` and `column` fields.
3. Add getters and a `move` method. (See Exercise02.)
4. Generate tests for `Knight`.
5. Complete the `move` method and confirm it's correct with tests.
    See https://en.wikipedia.org/wiki/Knight_(chess) for the Knight's movement rules.