public class Exercise06 {

    public static void main(String[] args) {
        // 1. Rewrite the following loop as a `while` statement.
        // Run the code before you make changes to better understand current behavior.
        // The transformation from `for` to `while` should not change behavior.

        for (int i = 3; i < 213; i += 13) {
            System.out.println(i);
        }
    }
}
