# Exercise13

1. Add a class to the project named `Hero`. It represents a super hero.
2. Add two fields:
    - `String name`
    - `Power[] powers`
3. Add a constructor that accepts a `String` and `Power[]` and sets the appropriate field.
4. Add getters for both the `name` and `powers` fields.