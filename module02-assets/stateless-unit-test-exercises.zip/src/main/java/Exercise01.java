public class Exercise01 {

    // INTEGER MATH

    // The following methods reimplement math operations.
    // add == +, subtract == -, multiply == *, divide == /
    // Parameters are operands that should be applied in order.
    // For example: a + b, not b + a.

    // 1. Open Exercise01Test in src/test/java and run all tests.
    // 2. Complete the add and subtract methods and make all tests pass.

    static int add(int a, int b) {
        return 0;
    }

    static int subtract(int a, int b) {
        return 0;
    }

    // 3. Add tests for multiply and divide in Exercise01Test.
    // Provide at least 6 test cases.
    // 4. Run all tests.
    // 5. Complete the multiply and divide methods and make all tests pass.

    static int multiply(int a, int b) {
        return 0;
    }

    static int divide(int a, int b) {
        return 0;
    }
}
