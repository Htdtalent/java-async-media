public class Exercise14 {

    public static void main(String[] args) {

        // 1. Uncomment the code below.
        // 2. Fix any errors by editing the Hero class.
        // 3. Confirm the output matches Expected Output.

//        Power levitation = new Power("Levitation");
//        Power flight = new Power("Flight");
//        Power blastPower = new Power("Blast Power");
//
//        Hero[] heroes = {
//                new Hero("Vision", new Power[]{levitation, blastPower}),
//                new Hero("Scarlet Witch", new Power[]{levitation, flight, new Power("Necromancy")}),
//                new Hero("Bumblebee", new Power[]{blastPower, flight})
//        };
//
//        for (Hero h : heroes) {
//
//            System.out.print(h.getName() + ": ");
//
//            String delimiter = "";
//            for (Power p : h.getPowers()) {
//                System.out.print(delimiter);
//                delimiter = ",";
//                System.out.print(p.getName());
//            }
//
//            System.out.println();
//        }

//        Expected Output:
//        Vision: Levitation,Blast Power
//        Scarlet Witch: Levitation,Flight,Necromancy
//        Bumblebee: Blast Power,Flight
    }
}
