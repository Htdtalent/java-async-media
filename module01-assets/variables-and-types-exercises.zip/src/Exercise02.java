public class Exercise02 {

    public static void main(String[] args) {
        // 1. Rename the variable numberOfApartments to unitCount.
        // 2. Run the code. (Be sure there are no errors.)
        int numberOfApartments = 73;

        System.out.println(numberOfApartments);
    }
}
