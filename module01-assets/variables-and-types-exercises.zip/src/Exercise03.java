public class Exercise03 {

    public static void main(String[] args) {
        // 1. Declare an integer variable named statesILivedInCount.
        // 2. Assign a literal value to it: the number of states you've lived in.
        // 3. Print the results with System.out.println.
        // 4. Run it.
    }
}
