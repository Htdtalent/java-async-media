# Exercise00b

Add a Java class named `Exercise00b` to this project.

1. Confirm that the IntelliJ Project window is visible. If it's not, from the _View_ menu, select _View -> Tool Windows -> Project_.
2. In the Project window, expand _variables-and-type_ to find the _src_ directory.
3. Right-click on _src_.
4. Then _New -> Java class_.
5. Type the name `Exercise00b`.
6. Press _Enter_.