# Exercise02

1. Open `learn.chess.Queen` and `learn.chess.QueenTest`.
2. To understand `Queen`, read its JavaDocs.
3. Implement the numbered changes in each class. 
    For each change, drive your development by writing tests.