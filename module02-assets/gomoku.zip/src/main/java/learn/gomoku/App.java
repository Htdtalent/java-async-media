package learn.gomoku;

public class App {

    public static void main(String[] args) {
    }
}
