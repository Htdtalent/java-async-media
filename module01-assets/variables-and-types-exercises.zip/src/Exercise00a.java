public class Exercise00a {
    public static void main(String[] args) {
        // 1. Add a single line comment below. Hint: this instruction is a single line comment.

        /* 2. Add a multi-line comment below.
        Hint: this instruction is a multi-line comment.
         */
    }
}
