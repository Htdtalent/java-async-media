import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import ToDos from './ToDos';

function App() {
  return (
    <div className="container mt-2">
      <ToDos />
    </div>
  );
}

export default App;
