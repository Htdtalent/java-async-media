public class Exercise06 {

    public static void main(String[] args) {

        int a = -55;
        int b = 5023;
        int c = 11;

        // 1. Declare an integer variable `sum`.
        // 2. Calculate the sum of a, b, c and the literal value -13 and store it in sum.
        // 3. Print the result.
    }
}
