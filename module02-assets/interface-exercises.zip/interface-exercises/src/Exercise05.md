# Exercise05

1. Add a new class to the project named `BankAccount`.
2. `BankAccount` must implement `MoneyStorage`.
3. Complete the implementation. Add fields, constructors, and getters as required.
    (Refer to `Mortgage` for inspiration, but with a positive balance.)
5. Rules:
    - Deposits must be positive values.
    - Can overdraw up to -25.00 dollars, but no lower. 
    (The balance is allowed to go negative.)