public class Exercise21 {

    public static void main(String[] args) {
        // 1. Add newline escape sequences so each sentence prints on its own line.
        String alphabet = "A is for alphabet. B is for briny. C is for cowlick.";
        System.out.println(alphabet);
    }
}
