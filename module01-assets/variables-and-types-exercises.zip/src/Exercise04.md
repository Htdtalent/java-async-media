# Exercise04

1. Add a new Java class named `Exercise04` to the project.
2. Add a `main` method to the class.
3. Declare an integer variable `heightInInches`.
4. Assign a literal value: your height in inches.
4. Print the result.
5. Run the code.