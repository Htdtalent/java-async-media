package learn;

public class Color {

    private final String name;

    public Color(String name) {
        this.name = name;
    }

    // 1. Override Color .equals and .hashCode to use the `name` field.
    // (Hint: IntelliJ can generate these methods for you.)
}
