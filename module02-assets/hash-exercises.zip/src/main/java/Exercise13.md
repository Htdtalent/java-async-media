# Exercise13

1. Add a class, `Student`, to the project.
2. Add fields:
    - `int studentId`
    - `String firstName`
    - `String lastName`
3. Create getters and setters.
4. Add a class, `Exercise13`, to the project.
5. Add a `main` method.
6. Inside, instantiate a `HashMap<Integer, Student>`.
7. Add at least three students to the map using their studentId as the key.
8. Retrieve one student and display them.
9. Delete one student.
10. Display all students.