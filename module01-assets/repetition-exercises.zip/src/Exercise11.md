# Exercise11

1. Add a new class, `Exercise11`, to this project.
2. Add a `main` method.
3. Collect three integers from a user: `start`, `end`, and `increment`.
4. Write a loop to sum values from `start` to `end` counting by the `increment`.
5. Print the result.