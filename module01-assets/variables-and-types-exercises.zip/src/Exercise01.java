public class Exercise01 {

    public static void main(String[] args) {
        // 1. Change the value of the monthsUntilMyBirthday variable
        // to the number of months until your birthday.
        // 2. Run the code.
        // Hint: Right-click on this file and select Run -> Exercise01.main
        int monthsUntilMyBirthday = -1;

        System.out.println("Months until my birthday:");
        System.out.println(monthsUntilMyBirthday);
    }
}
