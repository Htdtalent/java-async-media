public class Exercise19 {

    public static void main(String[] args) {
        String message = "Mucho Mucho Amor";
        System.out.println(message);
        // 1. Print the length of the message below.
        // Leave existing code intact.
    }
}
