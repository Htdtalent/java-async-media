# Exercise14

1. Add a new class named `Exercise14` to the project.
2. Add a `main` method.
3. Declare a variable `gradeLevel` and assign a literal value 1-12. Determine the appropriate type.
4. Declare a boolean variable `isSenior`. Use an expression to set the value to `true` if `gradeLevel` equals `12`.
5. Declare a boolean variable `isInterestedInVolunteering`.
6. Declare a boolean variable `shouldSendVolunteerInfo`. Use an expression to set the value. It should be `true` if both `isSenior` and `isInterestedInVolunteering` are `true`.
7. Print the final result.