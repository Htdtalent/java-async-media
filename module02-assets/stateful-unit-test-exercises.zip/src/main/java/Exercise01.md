# Exercise01

1. Open `learn.Submarine` from src/main and `learn.SubmarineTest` from src/test.
2. To understand `Submarine`, read its JavaDocs.
3. Implement the numbered changes in each class. For each change, drive your development by writing tests.
    Your process should be:
    - Write some code. Confirm it's correct with a test.
    - Write some code. Confirm it's correct with a test.
    - Repeat until complete.