public class Exercise09 {

    public static void main(String[] args) {

        double a = 93602.52968612382;
        double b = -4817.496614294316;
        double c = 46338.06248816222;

        // 1. Calculate the average of a, b, and c and store the value in a new variable.
        // 2. Print the result.
        // Expected value: 45041.03185 (give or take)
    }
}
