public class Exercise17 {
    public static void main(String[] args) {
        // 1. Declare a string variable `phrase`.
        // 2. Use string concatenation to assign a value. Concatenate adjective and noun.
        // Be sure to add a space in between.
        // 3. Print the result.
        // Expected Output: "happy moon"

        String adjective = "happy";
        String noun = "moon";
    }
}
