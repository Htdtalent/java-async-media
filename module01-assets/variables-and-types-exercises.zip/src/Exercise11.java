public class Exercise11 {

    public static void main(String[] args) {
        // 1. Change the price to make isCheap true.
        double price = 33.50;

        boolean isCheap = price < 4.95;

        System.out.println(isCheap);
    }
}
