# Exercise14

1. Create a class to represent something that interests you. If you're a collector, maybe the thing you collect?
Ideas: garden plants, video game characters, novelists, Studio Ghibli movies, the tallest buildings in the world...
Add appropriate fields, getters and setters, and constructors.
2. Create a second class, `Exercise14`, and add a `main` method.
3. Create an `ArrayList<T>` to hold instances of your new class.
4. Instantiate several objects and add them to the list.
5. Loop through the instances and print their values.