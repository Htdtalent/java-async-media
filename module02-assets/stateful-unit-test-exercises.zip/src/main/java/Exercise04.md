# Exercise04

1. Open both `LineItem` and `Order` in the `learn.commerce` package.
2. Read their JavaDocs to understand what they are and how they operate.
3. Open `learn.commerce.OrderTest` and check the existing tests.
4. Implement the requested changes in both `Order` and `OrderTest`. Use your tests to guide development.